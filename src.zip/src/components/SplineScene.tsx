'use client'

import Spline from '@splinetool/react-spline';

export default function SplineScene() {
  return (
    <div className="w-full h-[400px] relative">
      <Spline scene="https://prod.spline.design/EDlVJszplM6kpmIW/scene.splinecode" />
    </div>
  );
}

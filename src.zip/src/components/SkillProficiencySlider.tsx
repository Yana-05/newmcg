"use client";

import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";

interface SkillProficiencySliderProps {
    skill: string;
    value: number;
    onChange: (value: number) => void;
}

export default function SkillProficiencySlider({
    skill,
    value,
    onChange
}: SkillProficiencySliderProps) {
    return (
        <div className="space-y-2">
            <div className="flex justify-between items-center">
                <Label className="text-sm font-medium">{skill}</Label>
                <span className="text-sm text-muted-foreground">{value}%</span>
            </div>
            <Slider
                value={[value]}
                onValueChange={([newValue]) => onChange(newValue)}
                max={100}
                step={1}
                className="w-full SliderRoot"
            />
        </div>
    );
}
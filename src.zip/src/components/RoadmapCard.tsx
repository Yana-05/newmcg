import { motion } from 'framer-motion'
import { Card, CardContent, CardHeader, CardTitle, CardDescription, } from '@/components/ui/card'




export default function RoadmapCard({ icon, title, content }: { icon: React.ReactNode, title: string, content: React.ReactNode }) {
    return (
        <motion.div
            whileHover={{ scale: 1.007 }}
            transition={{ type: "spring", stiffness: 300 }}
        >
            <Card className="h-full">
                <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                        {icon}
                        <span>{title}</span>
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    {typeof content === 'string' ? <p>{content}</p> : content}
                </CardContent>
            </Card>
        </motion.div>
    )
}
import { ResumeValues } from "@/lib/validation";
import { RESUME_TEMPLATES, TemplateId } from "./resume-templates";

interface ResumePreviewProps {
  resumeData: ResumeValues;
  contentRef?: React.Ref<HTMLDivElement>;
  className?: string;
  template?: TemplateId;
}

export default function ResumePreview({
  resumeData,
  contentRef,
  className,
  template = "classic",
}: ResumePreviewProps) {
  const TemplateComponent = RESUME_TEMPLATES[template];

  return <TemplateComponent
    resumeData={resumeData}
    contentRef={contentRef}
    className={className}
  />;
}
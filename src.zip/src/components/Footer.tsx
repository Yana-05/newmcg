const Footer = () => {
    return (
        <footer className="py-8 px-4 md:px-6 lg:px-8 bg-white border-t border-gray-200 mt-auto">
            <div className="container mx-auto flex flex-col md:flex-row justify-between items-center">
                <p className="text-gray-600 mb-4 md:mb-0">&copy; 2023 Career Boost AI. All rights reserved.</p>
                <nav className="flex space-x-6">
                    <a href="#" className="text-gray-600 hover:text-indigo-600 transition-colors">Privacy Policy</a>
                    <a href="#" className="text-gray-600 hover:text-indigo-600 transition-colors">Terms of Service</a>
                    <a href="#" className="text-gray-600 hover:text-indigo-600 transition-colors">Contact Us</a>
                </nav>
            </div>
        </footer>
    )
}

export default Footer
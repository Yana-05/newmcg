import { ChevronRight } from 'lucide-react'
import Link from 'next/link'
import { Button } from '@/components/ui/button'

interface FeatureSectionProps {
  id: string
  title: string
  description: string
  icon: React.ReactNode
  buttonText: string
  buttonLink: string
  imageUrl: string
  reverse?: boolean
}

export default function FeatureSection({
  id,
  title,
  description,
  icon,
  buttonText,
  buttonLink,
  imageUrl,
  reverse = false
}: FeatureSectionProps) {
  return (
    <div id={id} className={`flex flex-col ${reverse ? 'md:flex-row-reverse' : 'md:flex-row'} items-center gap-12`}>
      <div className="flex-1 space-y-6">
        <div className="inline-block p-3 bg-gray-100 rounded-2xl">
          {icon}
        </div>
        <h3 className="text-2xl md:text-3xl font-bold text-gray-900">
          {title}
        </h3>
        <p className="text-lg text-gray-600">
          {description}
        </p>
        <Link href={buttonLink}>
          <Button className="mt-4 bg-indigo-600 hover:bg-indigo-700">
            {buttonText}
            <ChevronRight className="ml-2 h-4 w-4" />
          </Button>
        </Link>
      </div>
      <div className="flex-1">
        <img
          src={imageUrl}
          alt={title}
          className="rounded-lg shadow-lg w-full"
        />
      </div>
    </div>
  )
} 
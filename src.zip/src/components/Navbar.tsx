"use client"

import Link from "next/link"
import { Button } from "./ui/button"
import { Home, FileText, Briefcase, LayoutDashboard, GraduationCap, Rocket, Menu, X } from 'lucide-react'
import LoginLogoutButton from "./LoginLogoutButton"
import { useState } from "react"

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <nav className="bg-white border-b border-gray-200 fixed w-full z-50 rounded-b-lg shadow-sm">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          {/* Logo and Brand */}
          <Link href="/" className="flex items-center space-x-3">
            <span className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-purple-600">
              CareerBoost
            </span>
          </Link>

          {/* Desktop Navigation Links */}
          <div className="hidden md:flex items-center space-x-8">
            <Link 
              href="/" 
              className="text-gray-600 hover:text-indigo-600 flex items-center space-x-2"
            >
              <Home className="h-4 w-4" />
              <span>Home</span>
            </Link>
            <Link 
              href="/dashboard" 
              className="text-gray-600 hover:text-indigo-600 flex items-center space-x-2"
            >
              <LayoutDashboard className="h-4 w-4" />
              <span>Dashboard</span>
            </Link>
            <Link 
              href="/resumes" 
              className="text-gray-600 hover:text-indigo-600 flex items-center space-x-2"
            >
              <FileText className="h-4 w-4" />
              <span>Resumes</span>
            </Link>
            <Link 
              href="/find-jobs" 
              className="text-gray-600 hover:text-indigo-600 flex items-center space-x-2"
            >
              <Briefcase className="h-4 w-4" />
              <span>Jobs</span>
            </Link>
            <Link 
              href="/progress-journey" 
              className="text-gray-600 hover:text-indigo-600 flex items-center space-x-2"
            >
              <GraduationCap className="h-4 w-4" />
              <span>Learning Pathway</span>
            </Link>
          </div>

          {/* Desktop Auth Buttons */}
          <div className="hidden md:flex items-center space-x-4">
           
            <LoginLogoutButton />
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden p-2 rounded-lg hover:bg-gray-100"
          >
            {isMenuOpen ? (
              <X className="h-6 w-6 text-gray-600" />
            ) : (
              <Menu className="h-6 w-6 text-gray-600" />
            )}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden py-4 space-y-4">
            <Link 
              href="/" 
              className="block px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg flex items-center space-x-2"
              onClick={() => setIsMenuOpen(false)}
            >
              <Home className="h-4 w-4" />
              <span>Home</span>
            </Link>
            <Link 
              href="/dashboard" 
              className="block px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg flex items-center space-x-2"
              onClick={() => setIsMenuOpen(false)}
            >
              <LayoutDashboard className="h-4 w-4" />
              <span>Dashboard</span>
            </Link>
            <Link 
              href="/resumes" 
              className="block px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg flex items-center space-x-2"
              onClick={() => setIsMenuOpen(false)}
            >
              <FileText className="h-4 w-4" />
              <span>Resumes</span>
            </Link>
            <Link 
              href="/find-jobs" 
              className="block px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg flex items-center space-x-2"
              onClick={() => setIsMenuOpen(false)}
            >
              <Briefcase className="h-4 w-4" />
              <span>Jobs</span>
            </Link>
            <Link 
              href="/progress-journey" 
              className="block px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg flex items-center space-x-2"
              onClick={() => setIsMenuOpen(false)}
            >
              <GraduationCap className="h-4 w-4" />
              <span>Learning Pathway</span>
            </Link>
            <div className="px-4 py-2 space-y-2">
              <Link href="/career-boost" onClick={() => setIsMenuOpen(false)}>
                <Button className="w-full bg-indigo-600 hover:bg-indigo-700 text-white flex items-center justify-center space-x-2">
                  <Rocket className="h-4 w-4" />
                  <span>Start Career Boost</span>
                </Button>
              </Link>
              <div className="w-full">
                <LoginLogoutButton />
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  )
} 
import { extractTextFromPdf } from '@/lib/pdf-parser';
import { NextResponse } from 'next/server';
import openai from "@/lib/openai"
import { ResumeValues } from '@/lib/validation';



const RESUME_SCHEMA_PROMPT = `
Parse the resume text into the following JSON schema exactly, matching both Prisma and Zod validation requirements:
{
  "title": string | "",
  "description": string | "",
  "firstName": string | "",
  "lastName": string | "",
  "jobTitle": string | "",
  "city": string | "",
  "country": string | "",
  "phone": string | "",
  "email": string | "",
  "workExperiences": [{
    "position": string | "",
    "company": string | "",
    "startDate": DateTime | "",  // ISO date string format
    "endDate": DateTime | "",    // ISO date string format
    "description": string | "" //!!!!very important!!!! must be in the format of the example provided in rule 6 Seperate each bullet point with a new line
  }],
  "educations": [{
    "degree": string | "",
    "school": string | "",
    "startDate": DateTime | "",  // ISO date string format
    "endDate": DateTime | "",    // ISO date string format
  }],
  "skills": string[],
  "summary": string | "",
  "colorHex": string | "#000000",
  "borderStyle": string | "squircle",
  "photoUrl": string | ""
}

Important rules:
1. All string fields should be trimmed of whitespace
2. If a field is not found in the resume, use an empty string "" for optional fields
3. For arrays (workExperiences, educations, skills), if none found, use empty arrays []
4. Dates should be in ISO format (e.g., "2024-03-21T00:00:00.000Z")
5. For current positions, use null for endDate
6. this is an example of work experience description: • Architected and developed robust web applications using Next.js, React, and TypeScript\\n• Improved application performance by 40% through implementation of Redis caching\\n• Led a team of 5 developers in delivering critical features ahead of schedule\\n
7. Ensure all text is properly cleaned of any special characters or formatting artifacts
8. Use default values from Prisma schema where appropriate:
   - colorHex should default to "#000000" if not specified
   - borderStyle should default to "squircle" if not specified
9. Skills should be an array of individual skills, properly separated
10. Don't include any fields that aren't in the Prisma schema (like id, userId, createdAt, updatedAt)
11. if the parsed resume text doesnt contain professional summary, generate one using the skills and work experiences
`;


export async function POST(request: Request) {
    try {
        const formData = await request.formData();
        const file = formData.get('file') as File;

        if (!file) {
            return NextResponse.json({ error: 'No file provided' }, { status: 400 });
        }

        if (!file.type.includes('pdf')) {
            return NextResponse.json({ error: 'File must be a PDF' }, { status: 400 });
        }

        const MAX_SIZE = 5 * 1024 * 1024;
        if (file.size > MAX_SIZE) {
            return NextResponse.json({ error: 'File size must be less than 5MB' }, { status: 400 });
        }

        const bytes = await file.arrayBuffer();
        const buffer = Buffer.from(bytes);

        // Extract text from PDF
        const extractedText = await extractTextFromPdf(buffer);

        // Send to OpenAI for parsing
        const completion = await openai.chat.completions.create({
            messages: [
                {
                    role: "system",
                    content: `You are a resume parsing expert. Your task is to return ONLY a valid JSON object, with no additional text or explanation.${RESUME_SCHEMA_PROMPT}`
                },
                {
                    role: "user",
                    content: `Parse this resume text into a JSON object matching the specified schema. Return ONLY the JSON, no other text:\n\n${extractedText}`
                }
            ],
            model: "gpt-4",
        });
        const content = completion.choices[0].message.content;
        if (!content) {
            throw new Error('No content received from OpenAI');
        }

        try {
            const parsedResume = JSON.parse(content) as ResumeValues;
            return NextResponse.json({ resumeData: parsedResume });
        } catch (parseError) {
            console.error('OpenAI response:', content);
            throw new Error('Failed to parse OpenAI response as JSON');
        }

    } catch (error) {
        console.error('Error processing PDF:', error);
        return NextResponse.json({ error: 'Failed to process PDF' }, { status: 500 });
    }
} 
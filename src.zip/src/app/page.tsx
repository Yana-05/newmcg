import { Button } from "@/components/ui/button"
import FeatureCard from "@/components/FeatureCard"
import { FileText, Briefcase, TrendingUp, Zap, ChevronRight, CreditCard, FileUser, Check, Spline } from 'lucide-react'
import Link from "next/link"
import LoginLogoutButton from "@/components/LoginLogoutButton";
import dynamic from 'next/dynamic'

// Move this to the top of the file, outside the component
const SplineScene = dynamic(() => import('@/components/SplineScene'), {
  ssr: false,
  loading: () => (
    <div className="w-full h-[400px] bg-gradient-to-br from-indigo-50 to-purple-50 rounded-lg animate-pulse" />
  )
})

export default async function LandingPage() {

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-gray-100 to-white text-gray-800">

      <main>
        <section className="relative py-20 px-4 md:px-6 lg:px-8 text-center overflow-hidden md:min-h-[80vh] space-y-12">
          <div className="absolute inset-0 bg-gradient-to-br from-indigo-50 via-purple-50 to-white opacity-60"></div>
          
          {/* Grid layout for hero content and 3D model */}
          <div className="container mx-auto max-w-7xl relative z-10 grid md:grid-cols-2 gap-8 items-center">
            {/* Text content */}
            <div className="pb-8">
              <h2 className="pb-2 text-4xl md:text-5xl font-bold mb-6 text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-purple-600">
                Supercharge Your Career with AI
              </h2>
              <p className="text-[14px] md:text-xl mb-8 text-gray-700">
                Career Boost AI revolutionizes your job search with AI-powered tools for resume creation, job matching, skill analysis, and automated applications.
              </p>
              <div className="md:space-x-4 space-y-4">
                <Link
                  href="/career-boost"
                  className="inline-block text-lg px-8 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white rounded-md"
                >
                  <span className="flex items-center">
                    Start Your Career Boost <ChevronRight className="ml-2 h-5 w-5" />
                  </span>
                </Link>

                <Link
                  href="/resumes"
                  className="inline-block text-lg px-8 py-3 border border-indigo-200 text-indigo-600 hover:bg-indigo-50 rounded-md"
                >
                  <span className="flex items-center">
                    AI Resume Builder <ChevronRight className="ml-2 h-5 w-5" />
                  </span>
                </Link>
              </div>
            </div>

            {/* 3D Model */}
            <SplineScene />
          </div>
        </section>

        <section id="features" className="py-24 px-4 md:px-6 lg:px-8 bg-white">
          <div className="container mx-auto max-w-7xl">
            <div className="text-center mb-16">
              <span className="text-indigo-600 font-semibold text-sm uppercase tracking-wider">Why Choose Us</span>
              <h3 className="text-4xl font-bold mt-2 mb-4 text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-purple-600">
                Transform Your Career Journey
              </h3>
              <p className="text-gray-600 max-w-2xl mx-auto">
                Leverage AI-powered tools and expert insights to accelerate your professional growth
              </p>
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
              <div className="group h-full">
                <div className="h-full p-6 bg-white rounded-xl shadow-sm hover:shadow-lg transition-all duration-300 border border-gray-100 hover:border-indigo-200 relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-br from-indigo-50 to-purple-50 rounded-bl-full opacity-50"></div>
                  
                  <div className="relative">
                    <div className="p-3 bg-indigo-50 rounded-lg inline-block mb-4">
                      <FileText className="h-6 w-6 text-indigo-600" />
                    </div>
                    <h4 className="text-xl font-semibold text-gray-900 mb-4">
                      AI Resume Builder
                    </h4>
                    <ul className="space-y-3">
                      <li className="flex items-start space-x-3">
                        <span className="flex-shrink-0 w-5 h-5 bg-indigo-100 rounded-full flex items-center justify-center mt-0.5">
                          <span className="w-2 h-2 bg-indigo-600 rounded-full"></span>
                        </span>
                        <span className="text-gray-600 text-sm">Smart template matching for your industry</span>
                      </li>
                      <li className="flex items-start space-x-3">
                        <span className="flex-shrink-0 w-5 h-5 bg-indigo-100 rounded-full flex items-center justify-center mt-0.5">
                          <span className="w-2 h-2 bg-indigo-600 rounded-full"></span>
                        </span>
                        <span className="text-gray-600 text-sm">AI-powered content optimization</span>
                      </li>
                      <li className="flex items-start space-x-3">
                        <span className="flex-shrink-0 w-5 h-5 bg-indigo-100 rounded-full flex items-center justify-center mt-0.5">
                          <span className="w-2 h-2 bg-indigo-600 rounded-full"></span>
                        </span>
                        <span className="text-gray-600 text-sm">ATS-friendly formatting</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>

              <div className="group h-full">
                <div className="h-full p-6 bg-white rounded-xl shadow-sm hover:shadow-lg transition-all duration-300 border border-gray-100 hover:border-purple-200 relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-br from-purple-50 to-indigo-50 rounded-bl-full opacity-50"></div>
                  
                  <div className="relative">
                    <div className="p-3 bg-purple-50 rounded-lg inline-block mb-4">
                      <Briefcase className="h-6 w-6 text-purple-600" />
                    </div>
                    <h4 className="text-xl font-semibold text-gray-900 mb-4">
                      Smart Job Matching
                    </h4>
                    <ul className="space-y-3">
                      <li className="flex items-start space-x-3">
                        <span className="flex-shrink-0 w-5 h-5 bg-purple-100 rounded-full flex items-center justify-center mt-0.5">
                          <span className="w-2 h-2 bg-purple-600 rounded-full"></span>
                        </span>
                        <span className="text-gray-600 text-sm">Personalized job recommendations</span>
                      </li>
                      <li className="flex items-start space-x-3">
                        <span className="flex-shrink-0 w-5 h-5 bg-purple-100 rounded-full flex items-center justify-center mt-0.5">
                          <span className="w-2 h-2 bg-purple-600 rounded-full"></span>
                        </span>
                        <span className="text-gray-600 text-sm">Skills-based matching system</span>
                      </li>
                      <li className="flex items-start space-x-3">
                        <span className="flex-shrink-0 w-5 h-5 bg-purple-100 rounded-full flex items-center justify-center mt-0.5">
                          <span className="w-2 h-2 bg-purple-600 rounded-full"></span>
                        </span>
                        <span className="text-gray-600 text-sm">Salary insights and analysis</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>

              <div className="group h-full">
                <div className="h-full p-6 bg-white rounded-xl shadow-sm hover:shadow-lg transition-all duration-300 border border-gray-100 hover:border-indigo-200 relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-br from-indigo-50 to-purple-50 rounded-bl-full opacity-50"></div>
                  
                  <div className="relative">
                    <div className="p-3 bg-indigo-50 rounded-lg inline-block mb-4">
                      <TrendingUp className="h-6 w-6 text-indigo-600" />
                    </div>
                    <h4 className="text-xl font-semibold text-gray-900 mb-4">
                      Career Analytics
                    </h4>
                    <ul className="space-y-3">
                      <li className="flex items-start space-x-3">
                        <span className="flex-shrink-0 w-5 h-5 bg-indigo-100 rounded-full flex items-center justify-center mt-0.5">
                          <span className="w-2 h-2 bg-indigo-600 rounded-full"></span>
                        </span>
                        <span className="text-gray-600 text-sm">Skill gap analysis</span>
                      </li>
                      <li className="flex items-start space-x-3">
                        <span className="flex-shrink-0 w-5 h-5 bg-indigo-100 rounded-full flex items-center justify-center mt-0.5">
                          <span className="w-2 h-2 bg-indigo-600 rounded-full"></span>
                        </span>
                        <span className="text-gray-600 text-sm">Growth trajectory planning</span>
                      </li>
                      <li className="flex items-start space-x-3">
                        <span className="flex-shrink-0 w-5 h-5 bg-indigo-100 rounded-full flex items-center justify-center mt-0.5">
                          <span className="w-2 h-2 bg-indigo-600 rounded-full"></span>
                        </span>
                        <span className="text-gray-600 text-sm">Industry trend insights</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>

              <div className="group h-full">
                <div className="h-full p-6 bg-white rounded-xl shadow-sm hover:shadow-lg transition-all duration-300 border border-gray-100 hover:border-purple-200 relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-br from-purple-50 to-indigo-50 rounded-bl-full opacity-50"></div>
                  
                  <div className="relative">
                    <div className="p-3 bg-purple-50 rounded-lg inline-block mb-4">
                      <FileUser className="h-6 w-6 text-purple-600" />
                    </div>
                    <h4 className="text-xl font-semibold text-gray-900 mb-4">
                      Cover Letters
                    </h4>
                    <ul className="space-y-3">
                      <li className="flex items-start space-x-3">
                        <span className="flex-shrink-0 w-5 h-5 bg-purple-100 rounded-full flex items-center justify-center mt-0.5">
                          <span className="w-2 h-2 bg-purple-600 rounded-full"></span>
                        </span>
                        <span className="text-gray-600 text-sm">AI-powered personalization</span>
                      </li>
                      <li className="flex items-start space-x-3">
                        <span className="flex-shrink-0 w-5 h-5 bg-purple-100 rounded-full flex items-center justify-center mt-0.5">
                          <span className="w-2 h-2 bg-purple-600 rounded-full"></span>
                        </span>
                        <span className="text-gray-600 text-sm">Company-specific tailoring</span>
                      </li>
                      <li className="flex items-start space-x-3">
                        <span className="flex-shrink-0 w-5 h-5 bg-purple-100 rounded-full flex items-center justify-center mt-0.5">
                          <span className="w-2 h-2 bg-purple-600 rounded-full"></span>
                        </span>
                        <span className="text-gray-600 text-sm">Professional tone matching</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="py-24 px-4 md:px-6 lg:px-8 bg-gradient-to-br from-gray-50 via-gray-100 to-white">
          <div className="container mx-auto max-w-7xl">
            <div className="text-center mb-16">
              <span className="text-indigo-600 font-semibold text-sm uppercase tracking-wider">Pricing Plans</span>
              <h3 className="text-4xl font-bold mt-2 mb-4 text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-purple-600">
                Choose Your Career Journey
              </h3>
              <p className="text-gray-600 max-w-2xl mx-auto">
                Select the perfect plan that aligns with your career goals
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
              {/* Starter Plan */}
              <div className="relative group">
                <div className="absolute inset-0 bg-gradient-to-r from-indigo-600 to-purple-600 rounded-2xl blur opacity-0 group-hover:opacity-10 transition-all duration-300"></div>
                <div className="relative h-full p-8 bg-white border border-gray-200 rounded-2xl hover:border-indigo-100 transition-all duration-300">
                  <div className="space-y-4">
                    <h4 className="text-xl font-semibold text-gray-900">Starter</h4>
                    <div className="flex items-baseline">
                      <span className="text-4xl font-bold text-gray-900">$9</span>
                      <span className="ml-2 text-gray-500">/month</span>
                    </div>
                    <p className="text-sm text-gray-500">Perfect for those starting their career journey</p>
                  </div>

                  <div className="mt-8">
                    <ul className="space-y-4">
                      <li className="flex items-center space-x-3">
                        <div className="flex-shrink-0 w-5 h-5 bg-indigo-50 rounded-full flex items-center justify-center">
                          <Check className="h-3 w-3 text-indigo-600" />
                        </div>
                        <span className="text-gray-600 text-sm">Basic Resume Builder</span>
                      </li>
                      <li className="flex items-center space-x-3">
                        <div className="flex-shrink-0 w-5 h-5 bg-indigo-50 rounded-full flex items-center justify-center">
                          <Check className="h-3 w-3 text-indigo-600" />
                        </div>
                        <span className="text-gray-600 text-sm">3 Resume Templates</span>
                      </li>
                      <li className="flex items-center space-x-3">
                        <div className="flex-shrink-0 w-5 h-5 bg-indigo-50 rounded-full flex items-center justify-center">
                          <Check className="h-3 w-3 text-indigo-600" />
                        </div>
                        <span className="text-gray-600 text-sm">Basic Job Matching</span>
                      </li>
                    </ul>
                  </div>

                  <div className="mt-8">
                    <Button className="w-full py-3 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white rounded-lg transition-all duration-200">
                      Get Started
                    </Button>
                  </div>
                </div>
              </div>

              {/* Pro Plan - Most Popular */}
              <div className="relative group">
                <div className="absolute inset-0 bg-gradient-to-r from-indigo-600 to-purple-600 rounded-2xl blur opacity-0 group-hover:opacity-10 transition-all duration-300"></div>
                <div className="relative h-full p-8 bg-white border-2 border-indigo-600 rounded-2xl shadow-lg scale-105">
                  <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                    <span className="inline-block px-4 py-1 bg-gradient-to-r from-indigo-600 to-purple-600 rounded-full text-white text-sm font-medium">
                      Most Popular
                    </span>
                  </div>
                  <div className="space-y-4">
                    <h4 className="text-xl font-semibold text-gray-900">Pro</h4>
                    <div className="flex items-baseline">
                      <span className="text-4xl font-bold text-gray-900">$19</span>
                      <span className="ml-2 text-gray-500">/month</span>
                    </div>
                    <p className="text-sm text-gray-500">Ideal for professionals seeking career growth</p>
                  </div>

                  <div className="mt-8">
                    <ul className="space-y-4">
                      <li className="flex items-center space-x-3">
                        <div className="flex-shrink-0 w-5 h-5 bg-indigo-50 rounded-full flex items-center justify-center">
                          <Check className="h-3 w-3 text-indigo-600" />
                        </div>
                        <span className="text-gray-600 text-sm">Advanced Resume Builder</span>
                      </li>
                      <li className="flex items-center space-x-3">
                        <div className="flex-shrink-0 w-5 h-5 bg-indigo-50 rounded-full flex items-center justify-center">
                          <Check className="h-3 w-3 text-indigo-600" />
                        </div>
                        <span className="text-gray-600 text-sm">Unlimited Templates</span>
                      </li>
                      <li className="flex items-center space-x-3">
                        <div className="flex-shrink-0 w-5 h-5 bg-indigo-50 rounded-full flex items-center justify-center">
                          <Check className="h-3 w-3 text-indigo-600" />
                        </div>
                        <span className="text-gray-600 text-sm">AI Cover Letter Generator</span>
                      </li>
                      <li className="flex items-center space-x-3">
                        <div className="flex-shrink-0 w-5 h-5 bg-indigo-50 rounded-full flex items-center justify-center">
                          <Check className="h-3 w-3 text-indigo-600" />
                        </div>
                        <span className="text-gray-600 text-sm">Priority Job Matching</span>
                      </li>
                      <li className="flex items-center space-x-3">
                        <div className="flex-shrink-0 w-5 h-5 bg-indigo-50 rounded-full flex items-center justify-center">
                          <Check className="h-3 w-3 text-indigo-600" />
                        </div>
                        <span className="text-gray-600 text-sm">Career Analytics Dashboard</span>
                      </li>
                    </ul>
                  </div>

                  <div className="mt-8">
                    <Button className="w-full py-3 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white rounded-lg transition-all duration-200">
                      Get Pro Access
                    </Button>
                  </div>
                </div>
              </div>

              {/* Enterprise Plan */}
              <div className="relative group">
                <div className="absolute inset-0 bg-gradient-to-r from-indigo-600 to-purple-600 rounded-2xl blur opacity-0 group-hover:opacity-10 transition-all duration-300"></div>
                <div className="relative h-full p-8 bg-white border border-gray-200 rounded-2xl hover:border-indigo-100 transition-all duration-300">
                  <div className="space-y-4">
                    <h4 className="text-xl font-semibold text-gray-900">Enterprise</h4>
                    <div className="flex items-baseline">
                      <span className="text-4xl font-bold text-gray-900">$49</span>
                      <span className="ml-2 text-gray-500">/month</span>
                    </div>
                    <p className="text-sm text-gray-500">For teams and organizations</p>
                  </div>

                  <div className="mt-8">
                    <ul className="space-y-4">
                      <li className="flex items-center space-x-3">
                        <div className="flex-shrink-0 w-5 h-5 bg-indigo-50 rounded-full flex items-center justify-center">
                          <Check className="h-3 w-3 text-indigo-600" />
                        </div>
                        <span className="text-gray-600 text-sm">Everything in Pro</span>
                      </li>
                      <li className="flex items-center space-x-3">
                        <div className="flex-shrink-0 w-5 h-5 bg-indigo-50 rounded-full flex items-center justify-center">
                          <Check className="h-3 w-3 text-indigo-600" />
                        </div>
                        <span className="text-gray-600 text-sm">Team Management</span>
                      </li>
                      <li className="flex items-center space-x-3">
                        <div className="flex-shrink-0 w-5 h-5 bg-indigo-50 rounded-full flex items-center justify-center">
                          <Check className="h-3 w-3 text-indigo-600" />
                        </div>
                        <span className="text-gray-600 text-sm">Custom Branding</span>
                      </li>
                      <li className="flex items-center space-x-3">
                        <div className="flex-shrink-0 w-5 h-5 bg-indigo-50 rounded-full flex items-center justify-center">
                          <Check className="h-3 w-3 text-indigo-600" />
                        </div>
                        <span className="text-gray-600 text-sm">API Access</span>
                      </li>
                    </ul>
                  </div>

                  <div className="mt-8">
                    <Button className="w-full py-3 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white rounded-lg transition-all duration-200">
                      Contact Sales
                    </Button>
                  </div>
                </div>
              </div>
            </div>

            {/* Annual Pricing Note */}
            <div className="mt-12 text-center">
              <p className="text-gray-600">
                Save 20% with{' '}
                <span className="text-indigo-600 font-semibold">annual billing</span>
              </p>
            </div>
          </div>
        </section>

        <section className="py-20 px-4 md:px-6 lg:px-8 bg-gradient-to-br from-gray-50 via-indigo-50 to-purple-50">
          <div className="container mx-auto text-center">
            <h3 className="text-3xl font-bold mb-6 text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-purple-600">
              Ready to Boost Your Career?
            </h3>
            <p className="text-xl mb-8 text-gray-700">
              Join thousands of professionals who have accelerated their careers with Career Boost AI.
            </p>
            <Button size="lg" className="text-lg px-8 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white">
              Get Started Now <ChevronRight className="ml-2 h-5 w-5" />
            </Button>
          </div>
        </section>
      </main>

      <footer className="py-8 px-4 md:px-6 lg:px-8 bg-white border-t border-gray-200">
        <div className="container mx-auto flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-600 mb-4 md:mb-0">&copy; 2023 Career Boost AI. All rights reserved.</p>
          <nav className="flex space-x-6">
            <a href="#" className="text-gray-600 hover:text-indigo-600 transition-colors">Privacy Policy</a>
            <a href="#" className="text-gray-600 hover:text-indigo-600 transition-colors">Terms of Service</a>
            <a href="#" className="text-gray-600 hover:text-indigo-600 transition-colors">Contact Us</a>
          </nav>
        </div>
      </footer>
    </div>
  )
}




"use client";

import { Button } from "@/components/ui/button";
import { PlusSquare } from "lucide-react";
import { useState } from "react";
import { TemplateSelectionModal } from "@/components/TemplateSelectionModal";
import usePremiumModal from "@/hooks/usePremiumModal";

interface CreateResumeButtonProps {
  canCreate: boolean;
}

export default function CreateResumeButton({
  canCreate,
}: CreateResumeButtonProps) {
  const [isTemplateModalOpen, setIsTemplateModalOpen] = useState(false);
  const premiumModal = usePremiumModal();

  if (canCreate) {
    return (
      <>
        <Button
          onClick={() => setIsTemplateModalOpen(true)}
          className="flex w-fit gap-2 gradient-primary h-12"
        >
          <PlusSquare className="size-8" />
          <span className="text-lg">New resume</span>
        </Button>

        <TemplateSelectionModal
          open={isTemplateModalOpen}
          onClose={() => setIsTemplateModalOpen(false)}
        />
      </>
    );
  }

  return (
    <Button
      onClick={() => premiumModal.setOpen(true)}
      className="mx-auto flex w-fit gap-2"
    >
      <PlusSquare className="size-5" />
      New resume
    </Button>
  );
}

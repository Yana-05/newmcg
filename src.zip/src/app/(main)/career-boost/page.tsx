"use client"
import { Button } from "@/components/ui/button"
import { Briefcase, TrendingUp, Zap, ChevronRight, FileUser } from 'lucide-react'
import Link from "next/link"
import { motion } from "framer-motion"
import FeatureSection from "@/components/FeatureSection"

export default function CareerBoostFeatures() {
    return (
        <div className="min-h-screen bg-gradient-to-br from-gray-50 via-gray-100 to-white text-gray-800">
            <main className="py-12 px-4 md:px-6 lg:px-8 mb-24">
                <div className="container mx-auto">
                    <motion.h2
                        className="text-3xl md:text-4xl font-bold mb-12 text-center text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-purple-600"
                        initial={{ opacity: 0, y: -20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.5 }}
                    >
                        Boost Your Career with AI-Powered Tools
                    </motion.h2>
                    <nav className="hidden md:flex space-x-6 w-full mx-auto py-4">
                        <a href="#job-matching" className="text-gray-600 hover:text-indigo-600 transition-colors">Job Matching &#62;&#62;</a>
                        <a href="#skill-analysis" className="text-gray-600 hover:text-indigo-600 transition-colors">Skill Analysis &#62;&#62;</a>
                        <a href="#ai-cover-letter" className="text-gray-600 hover:text-indigo-600 transition-colors">AI Cover Letter &#62;&#62;</a>
                    </nav>

                    <div className="space-y-32">
                        <FeatureSection
                            id="job-matching"
                            title="Smart Job Matching"
                            description="Find the perfect job opportunities that match your unique skills and experience. Simply upload your resume or enter your LinkedIn profile URL, and we'll fetch a list of recent jobs posted on LinkedIn that align with your skillset."
                            icon={<Briefcase className="h-16 w-16 text-indigo-600" />}
                            buttonText="Start Job Matching"
                            buttonLink="/find-jobs"
                            imageUrl="/job-matching.png"
                        />

                        <FeatureSection
                            id="skill-analysis"
                            title="Skill Analysis & Roadmap"
                            description="Get a complete analysis of your current skill set and receive a personalized roadmap designed to help you upskill. We'll recommend technologies to learn, concepts to master, and provide direct links to relevant courses to get you started. All based on your resume or LinkedIn profile."
                            icon={<TrendingUp className="h-16 w-16 text-purple-600" />}
                            buttonText="Analyze Your Skills"
                            buttonLink="/upskill-roadmap"
                            imageUrl="/roadmap.jpg"
                            reverse
                        />

                        <FeatureSection
                            id="ai-cover-letter"
                            title="AI Cover Letter generation"
                            description="Generate customised cover letter for each individual jobs relevant to their requirements with one click, saving you time and increasing your chances of landing your dream job."
                            icon={<FileUser className="h-10 w-10 text-purple-600" />}
                            buttonText="Generate Cover Letter"
                            buttonLink="/auto-apply"
                            imageUrl="coverletter.jpg"
                        />
                    </div>
                </div>
            </main>
        </div>
    )
}

// FeatureSection component remains the same
'use server'

import prisma from "@/lib/prisma"
import { createClient } from "@/utils/supabase/server";

type UserProgress = NonNullable<Awaited<ReturnType<typeof prisma.userProgress.findFirst>>> & {
  technologies: NonNullable<Awaited<ReturnType<typeof prisma.technologyProgress.findMany>>>;
  courses: NonNullable<Awaited<ReturnType<typeof prisma.courseProgress.findMany>>>;
  roadmap?: NonNullable<Awaited<ReturnType<typeof prisma.upskillRoadmap.findFirst>>> & {
    strategicLearningPath: any[];
    learningInterventions: any[];
  };
}

export async function getUserProgress() {
  const supabase = await createClient();
  const { data, error } = await supabase.auth.getUser();
  if (!data.user) throw new Error("Unauthorized")

  // Add type definition for progress
  let progress: UserProgress | null = await prisma.userProgress.findFirst({
    where: { userId: data.user.id },
    include: {
      technologies: true,
      courses: true,
      roadmap: {
        include: {
          strategicLearningPath: true,
          learningInterventions: true,
        }
      }
    },
    orderBy: { createdAt: 'desc' }
  })

  // If no progress exists, create initial progress from the latest roadmap
  if (!progress) {
    const latestRoadmap = await prisma.upskillRoadmap.findFirst({
      where: { userId: data.user.id },
      include: {
        strategicLearningPath: true,
        learningInterventions: true,
      },
      orderBy: { createdAt: 'desc' }
    })

    if (latestRoadmap) {
      progress = await prisma.userProgress.create({
        data: {
          userId: data.user.id,
          roadmapId: latestRoadmap.id,
          technologies: {
            create: latestRoadmap.strategicLearningPath.flatMap(phase =>
              phase.technologiesToLearn.map(tech => ({
                name: tech,
                completed: false
              }))
            )
          },
          courses: {
            create: latestRoadmap.learningInterventions.map(course => ({
              name: course.courseTitle,
              status: 'not-started'
            }))
          }
        },
        include: {
          technologies: true,
          courses: true,
        }
      })
    }
  }

  return progress
}

export async function updateTechnologyProgress(techId: string) {
  const supabase = await createClient();
  const { data, error } = await supabase.auth.getUser();
  if (!data.user) throw new Error("Unauthorized")

  const currentTech = await prisma.technologyProgress.findUnique({
    where: { id: techId }
  })

  if (!currentTech) throw new Error("Technology not found")

  const tech = await prisma.technologyProgress.update({
    where: { id: techId },
    data: {
      completed: {
        set: !currentTech.completed  // Toggle the boolean value
      }
    }
  })

  return tech
}

export async function updateCourseProgress(courseId: string, status: string) {
  const supabase = await createClient();
  const { data, error } = await supabase.auth.getUser();
  if (!data.user) throw new Error("Unauthorized")

  const course = await prisma.courseProgress.update({
    where: { id: courseId },
    data: { status }
  })

  return course
}

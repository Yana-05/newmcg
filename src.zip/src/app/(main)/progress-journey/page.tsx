'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { Button } from "@/components/ui/button"
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Checkbox } from "@/components/ui/checkbox"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Book, Trophy } from 'lucide-react'
import { getUserProgress, updateTechnologyProgress, updateCourseProgress } from './actions'
import { TechnologyProgress, CourseProgress } from '@prisma/client'

type UserProgressData = {
  technologies: TechnologyProgress[];
  courses: CourseProgress[];
} | null

export default function LearningProgress() {
  const [userProgress, setUserProgress] = useState<UserProgressData>(null)

  useEffect(() => {
    const fetchProgress = async () => {
      const progress = await getUserProgress()
      setUserProgress(progress)
    }
    fetchProgress()
  }, [])

  if (!userProgress) return null

  const completedTechnologies = userProgress.technologies.filter(tech => tech.completed).length
  const totalTechnologies = userProgress.technologies.length
  const progressPercentage = totalTechnologies > 0 ? (completedTechnologies / totalTechnologies) * 100 : 0

  const handleTechnologyToggle = async (id: string) => {
    try {
      const updatedTech = await updateTechnologyProgress(id)
      if (!userProgress) return

      setUserProgress({
        ...userProgress,
        technologies: userProgress.technologies.map(tech =>
          tech.id === id ? { ...tech, completed: updatedTech.completed } : tech
        )
      })
    } catch (error) {
      console.error('Failed to update technology progress:', error)
    }
  }

  const handleCourseStatusChange = async (id: string, status: 'not-started' | 'in-progress' | 'completed') => {
    try {
      const updatedCourse = await updateCourseProgress(id, status)
      if (!userProgress) return

      setUserProgress({
        ...userProgress,
        courses: userProgress.courses.map(course =>
          course.id === id ? { ...course, status: updatedCourse.status } : course
        )
      })
    } catch (error) {
      console.error('Failed to update course status:', error)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-gray-100 to-white text-gray-800 py-12 px-4 sm:px-6 lg:px-8">
      <motion.div
        className="max-w-4xl mx-auto"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-4xl font-bold text-center mb-8 text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-purple-600">
          Your Learning Journey
        </h1>

        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Trophy className="h-6 w-6 text-yellow-500" />
              <span>Technology Progress</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="mb-6">
              <div className="flex justify-between mb-2">
                <span className="text-sm font-medium text-gray-700">Overall Progress</span>
                <span className="text-sm font-medium text-gray-700">
                  {completedTechnologies} / {totalTechnologies}
                </span>
              </div>
              <Progress value={progressPercentage} className="w-full" />
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {userProgress.technologies.map((tech) => (
                <div key={tech.id} className="flex items-center space-x-2">
                  <Checkbox
                    id={tech.id}
                    checked={tech.completed}
                    onCheckedChange={() => handleTechnologyToggle(tech.id)}
                  />
                  <label
                    htmlFor={tech.id}
                    className={`text-sm font-medium ${tech.completed ? 'text-green-600 line-through' : 'text-gray-700'}`}
                  >
                    {tech.name}
                  </label>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Book className="h-6 w-6 text-indigo-600" />
              <span>Course Progress</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="all" className="w-full">
              <TabsList className="grid w-full grid-cols-3 mb-4">
                <TabsTrigger value="all">All</TabsTrigger>
                <TabsTrigger value="in-progress">In Progress</TabsTrigger>
                <TabsTrigger value="completed">Completed</TabsTrigger>
              </TabsList>
              {['all', 'in-progress', 'completed'].map((tab) => (
                <TabsContent key={tab} value={tab}>
                  <ul className="space-y-4">
                    {userProgress.courses
                      .filter(course => tab === 'all' || course.status === tab)
                      .map((course) => (
                        <li key={course.id} className="flex items-center justify-between p-4 bg-white rounded-lg shadow">
                          <div className="flex items-center space-x-4">
                            <Badge variant={course.status === 'completed' ? 'default' : 'secondary'}>
                              {course.status === 'not-started' && 'Not Started'}
                              {course.status === 'in-progress' && 'In Progress'}
                              {course.status === 'completed' && 'Completed'}
                            </Badge>
                            <span className="font-medium">{course.name}</span>
                          </div>
                          <div className="flex space-x-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleCourseStatusChange(course.id, 'in-progress')}
                              disabled={course.status === 'in-progress'}
                            >
                              Start
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleCourseStatusChange(course.id, 'completed')}
                              disabled={course.status === 'completed'}
                            >
                              Complete
                            </Button>
                          </div>
                        </li>
                      ))}
                  </ul>
                </TabsContent>
              ))}
            </Tabs>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  )
}


import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { FileText, Briefcase, TrendingUp, ChevronRight, FileUser, BarChart, Clock, Star } from 'lucide-react'

export default function DashboardPage() {
  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Welcome back, User!</h1>
          <p className="text-gray-600 mt-2">{`Here's`} an overview of your career progress</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="p-6 hover:shadow-md transition-shadow">
            <div className="flex items-center space-x-4">
              <div className="p-3 bg-indigo-50 rounded-lg">
                <FileText className="h-6 w-6 text-indigo-600" />
              </div>
              <div>
                <p className="text-sm font-medium text-gray-600">Active Resumes</p>
                <h3 className="text-2xl font-bold text-gray-900">3</h3>
              </div>
            </div>
          </Card>

          <Card className="p-6 hover:shadow-md transition-shadow">
            <div className="flex items-center space-x-4">
              <div className="p-3 bg-purple-50 rounded-lg">
                <Briefcase className="h-6 w-6 text-purple-600" />
              </div>
              <div>
                <p className="text-sm font-medium text-gray-600">Job Applications</p>
                <h3 className="text-2xl font-bold text-gray-900">12</h3>
              </div>
            </div>
          </Card>

          <Card className="p-6 hover:shadow-md transition-shadow">
            <div className="flex items-center space-x-4">
              <div className="p-3 bg-indigo-50 rounded-lg">
                <TrendingUp className="h-6 w-6 text-indigo-600" />
              </div>
              <div>
                <p className="text-sm font-medium text-gray-600">Profile Views</p>
                <h3 className="text-2xl font-bold text-gray-900">48</h3>
              </div>
            </div>
          </Card>

          <Card className="p-6 hover:shadow-md transition-shadow">
            <div className="flex items-center space-x-4">
              <div className="p-3 bg-purple-50 rounded-lg">
                <Star className="h-6 w-6 text-purple-600" />
              </div>
              <div>
                <p className="text-sm font-medium text-gray-600">Saved Jobs</p>
                <h3 className="text-2xl font-bold text-gray-900">7</h3>
              </div>
            </div>
          </Card>
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Recent Activity */}
          <div className="lg:col-span-2">
            <Card className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-semibold text-gray-900">Recent Activity</h2>
                <Button variant="ghost" className="text-sm text-indigo-600">
                  View All
                </Button>
              </div>
              <div className="space-y-6">
                {[
                  {
                    icon: <FileText className="h-5 w-5 text-indigo-600" />,
                    title: "Resume Updated",
                    description: "Software Engineer Resume v2",
                    time: "2 hours ago"
                  },
                  {
                    icon: <Briefcase className="h-5 w-5 text-purple-600" />,
                    title: "Job Application Submitted",
                    description: "Senior Developer at TechCorp",
                    time: "1 day ago"
                  },
                  {
                    icon: <Star className="h-5 w-5 text-yellow-500" />,
                    title: "New Job Saved",
                    description: "Full Stack Developer at StartupX",
                    time: "2 days ago"
                  }
                ].map((activity, index) => (
                  <div key={index} className="flex items-start space-x-4">
                    <div className="p-2 bg-gray-50 rounded-lg">
                      {activity.icon}
                    </div>
                    <div className="flex-1">
                      <h3 className="text-sm font-medium text-gray-900">{activity.title}</h3>
                      <p className="text-sm text-gray-600">{activity.description}</p>
                    </div>
                    <span className="text-xs text-gray-500">{activity.time}</span>
                  </div>
                ))}
              </div>
            </Card>
          </div>

          {/* Quick Actions */}
          <div>
            <Card className="p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-6">Quick Actions</h2>
              <div className="space-y-4">
                <Button className="w-full justify-start text-left" variant="outline">
                  <FileText className="h-5 w-5 mr-3" />
                  Create New Resume
                </Button>
                <Button className="w-full justify-start text-left" variant="outline">
                  <FileUser className="h-5 w-5 mr-3" />
                  Generate Cover Letter
                </Button>
                <Button className="w-full justify-start text-left" variant="outline">
                  <Briefcase className="h-5 w-5 mr-3" />
                  Browse Jobs
                </Button>
                <Button className="w-full justify-start text-left" variant="outline">
                  <BarChart className="h-5 w-5 mr-3" />
                  View Analytics
                </Button>
              </div>
            </Card>

            {/* Subscription Status */}
            <Card className="p-6 mt-6 bg-gradient-to-br from-indigo-50 to-purple-50">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">Pro Plan</h3>
                  <p className="text-sm text-gray-600">Valid until Dec 2024</p>
                </div>
                <Star className="h-6 w-6 text-yellow-500" />
              </div>
              <Button className="w-full mt-4" variant="default">
                Manage Subscription
              </Button>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}

"use client"


import LoginLogoutButton from "@/components/LoginLogoutButton";
import LogoutButton from "@/components/logout/LogoutButton";
import { Button } from "@/components/ui/button";
import Link from "next/link";

export default function Navbar() {

  return (
    <header className="py-4 px-4 md:px-6 lg:px-8 border-b ">
      <div className="container mx-auto flex justify-between items-center">
        <Link href="/" className="flex items-center gap-2">

          <span className="text-2xl font-bold text-transparent bg-clip-text gradient-primary">
            MyCareerGrowth
          </span>
        </Link>
        <nav className="hidden md:flex space-x-6">
          <Link href="/progress-journey" className="text-gray-600 hover:text-indigo-600 transition-colors">
            Learning Pathway
          </Link>
          <a href="#features" className="text-gray-600 hover:text-indigo-600 transition-colors">Features</a>
          <a href="#pricing" className="text-gray-600 hover:text-indigo-600 transition-colors">Pricing</a>
          <a href="#contact" className="text-gray-600 hover:text-indigo-600 transition-colors">Contact</a>
        </nav>
        <div className="flex items-center gap-3">
          {/* <ThemeToggle /> */}
          <LoginLogoutButton />
        </div>
      </div>
    </header>
  );
}

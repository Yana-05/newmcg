
import prisma from "@/lib/prisma";
import { resumeDataInclude } from "@/lib/types";
import ClientFindJobs from './ClientFindJobs';
import Footer from "@/components/Footer";
import { createClient } from "@/utils/supabase/server";

export default async function FindJobsPage() {
    const supabase = await createClient();
    const { data, error } = await supabase.auth.getUser();

    if (!data.user) {
        return null;
    }

    const resumes = await prisma.resume.findMany({
        where: {
            userId: data.user.id,
        },
        orderBy: {
            updatedAt: "desc",
        },
        include: {
            ...resumeDataInclude,
            workExperiences: true,
            educations: true
        },
    });

    return (
        <div className="container mx-auto py-8 px-4">
            <h1 className="text-3xl font-bold mb-6 text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-purple-600">Find Jobs relevant to your Skills</h1>
            <ClientFindJobs initialResumes={resumes} />
        </div>
    );
}
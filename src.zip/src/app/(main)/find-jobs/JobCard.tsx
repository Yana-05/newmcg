import { ArrowUpRight } from "lucide-react";

interface JobCardProps {
    job: {
        title: string;
        company_name: string;
        location: string;
        via: string;
        description: string;
        detected_extensions: {
            posted_at?: string;
            schedule_type?: string;
            work_from_home?: boolean;
        };
        apply_options: Array<{
            title: string;
            link: string;
        }>;
    };
}
export function JobCard({ job }: JobCardProps) {
    return (
        <div className="border rounded-lg p-4 mb-4 shadow-sm hover:shadow-md transition-shadow">
            <h3 className="text-lg font-semibold">{job.title}</h3>
            <div className="text-gray-600 mt-2 space-y-1">
                <p className="font-medium">{job.company_name}</p>
                <p>{job.location}</p>
                <div className="flex gap-2 flex-wrap text-sm">
                    {job.detected_extensions?.posted_at && (
                        <span className="bg-gray-100 px-2 py-1 rounded-full">
                            {job.detected_extensions.posted_at}
                        </span>
                    )}
                    {job.detected_extensions?.schedule_type && (
                        <span className="bg-gray-100 px-2 py-1 rounded-full">
                            {job.detected_extensions.schedule_type}
                        </span>
                    )}
                    {job.detected_extensions?.work_from_home && (
                        <span className="bg-green-100 text-green-800 px-2 py-1 rounded-full">
                            Remote
                        </span>
                    )}
                    {job.via && (
                        <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded-full">
                            via {job.via}
                        </span>
                    )}
                </div>
            </div>

            <p className="mt-3 text-gray-700 line-clamp-3">{job.description}</p>

            {/* {job.apply_options && job.apply_options.length > 0 && (
                <a
                    href={job.apply_options[0].link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-3 inline-flex items-center text-blue-600 hover:underline"
                >
                    Apply on {job.apply_options[0].title} <ArrowUpRight className="w-4 h-4 ml-1" />
                </a>
            )} */}
        </div>
    );
}
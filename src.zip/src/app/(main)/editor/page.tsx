import prisma from "@/lib/prisma";
import { resumeDataInclude } from "@/lib/types";
import { Metadata } from "next";
import ResumeEditor from "./ResumeEditor";
import { TemplateId } from "@/components/resume-templates";
import { createClient } from "@/utils/supabase/server";

interface PageProps {
  searchParams: Promise<{ resumeId?: string, template?: TemplateId }>;
}

export const metadata: Metadata = {
  title: "Design your resume",
};

export default async function Page({ searchParams }: PageProps) {
  const { resumeId, template = "classic" } = await searchParams;

  const supabase = await createClient();
  const { data, error } = await supabase.auth.getUser();

  if (!data.user) {
    return null;
  }

  const resumeToEdit = resumeId
    ? await prisma.resume.findUnique({
      where: { id: resumeId, userId: data.user.id },
      include: resumeDataInclude,
    })
    : null;

  return <ResumeEditor resumeToEdit={resumeToEdit} template={template as TemplateId} />;
}

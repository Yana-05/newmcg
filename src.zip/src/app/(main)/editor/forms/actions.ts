"use server";

import openai from "@/lib/openai";
import { canUseAITools } from "@/lib/permissions";
import { getUserSubscriptionLevel } from "@/lib/subscription";
import {
  GenerateSummaryInput,
  generateSummarySchema,
  GenerateWorkExperienceInput,
  generateWorkExperienceSchema,
  WorkExperience,
} from "@/lib/validation";
import { createClient } from "@/utils/supabase/server";


export async function generateSummary(input: GenerateSummaryInput) {
  const supabase = await createClient();
  const { data, error } = await supabase.auth.getUser();

  if (!data.user) {
    throw new Error("Unauthorized");
  }

  const subscriptionLevel = await getUserSubscriptionLevel(data.user.id);

  if (!canUseAITools(subscriptionLevel)) {
    throw new Error("Upgrade your subscription to use this feature");
  }

  const { jobTitle, workExperiences, educations, skills } =
    generateSummarySchema.parse(input);

  const systemMessage = `
    You are a job resume generator AI. Your task is to write a professional introduction summary section for a resume given the user's provided data.
    Only return the summary and do not include any other information in the response. Keep it concise and professional and include the most relevant information.
    `;

  const userMessage = `
    Please generate a professional resume summary from this data:

    Job title: ${jobTitle || "N/A"}

    Work experience:
    ${workExperiences
      ?.map(
        (exp) => `
        Position: ${exp.position || "N/A"} at ${exp.company || "N/A"} from ${exp.startDate || "N/A"} to ${exp.endDate || "Present"}

        Description:
        ${exp.description || "N/A"}
        `,
      )
      .join("\n\n")}

      Education:
    ${educations
      ?.map(
        (edu) => `
        Degree: ${edu.degree || "N/A"} at ${edu.school || "N/A"} from ${edu.startDate || "N/A"} to ${edu.endDate || "N/A"}
        `,
      )
      .join("\n\n")}

      Skills:
      ${skills}
    `;

  console.log("systemMessage", systemMessage);
  console.log("userMessage", userMessage);

  const completion = await openai.chat.completions.create({
    model: "gpt-4o-mini",
    messages: [
      {
        role: "system",
        content: systemMessage,
      },
      {
        role: "user",
        content: userMessage,
      },
    ],
  });

  const aiResponse = completion.choices[0].message.content;

  if (!aiResponse) {
    throw new Error("Failed to generate AI response");
  }

  return aiResponse;
}

export async function generateWorkExperience(
  input: GenerateWorkExperienceInput,
) {
  const supabase = await createClient();
  const { data, error } = await supabase.auth.getUser();

  if (!data.user) {
    throw new Error("Unauthorized");
  }

  const subscriptionLevel = await getUserSubscriptionLevel(data.user.id);

  if (!canUseAITools(subscriptionLevel)) {
    throw new Error("Upgrade your subscription to use this feature");
  }

  const { description } = generateWorkExperienceSchema.parse(input);

  const systemMessage = `
  You are an expert resume optimization AI specializing in crafting compelling, achievement-oriented work experience entries. Your goal is to transform job descriptions into powerful, concise narratives that highlight:
  Your response must be in the following JSON format and no other text below is an example containing bullet points, line breaks, and markdown:
  {
    "description": "• Architected and developed robust web applications using Next.js, React, and TypeScript\\n• Improved application performance by 40% through implementation of Redis caching\\n• Led a team of 5 developers in delivering critical features ahead of schedule\\n"
  }

1. Key Technical Skills
   - Each bullet point should start with • and use \\n for new lines
   - Use industry-standard terminology and acronyms

2. Quantifiable Achievements
   - Translate responsibilities into measurable impacts
   - Use specific metrics (%, $, time saved, performance improvements)
   - Demonstrate value through concrete outcomes

3. Action-Oriented Language
   - Start each bullet point with strong action verbs
   - Use past tense for completed actions
   - Avoid passive voice
   - Show progression and leadership

4. Formatting and Structure
   - Maintain a consistent, professional tone
   - Use 3-5 bullet points per role
   - Prioritize most impressive and relevant achievements
   - Tailor content to target industry/role

5. Context and Scope
   - Briefly explain project/team context
   - Highlight cross-functional collaboration
   - Show breadth and depth of responsibilities

Guidelines:
- Be concise yet comprehensive
- Focus on professional achievements
- Align description with common resume best practices`;

  const userMessage = `
 Generate an optimized work experience entry from the following job description:

Job Description: ${description}

Additional Context:
- Target Industry/Role: [Specify target industry or job role]
- Key Skills to Emphasize: [List any specific skills you want highlighted]
- Preferred Tone: [Professional, Technical, Creative, etc.]

Please provide a structured response that includes:
- Precise technical skills used
- Quantifiable achievements
- Clear impact of contributions
- Alignment with target role/industry
  `;

  const completion = await openai.chat.completions.create({
    model: "gpt-4o-mini",
    messages: [
      {
        role: "system",
        content: systemMessage,
      },
      {
        role: "user",
        content: userMessage,
      },
    ],
  });

  const aiResponse = completion.choices[0].message.content;

  if (!aiResponse) {
    throw new Error("Failed to generate AI response");
  }

  console.log(aiResponse);
  return {
    position: JSON.parse(aiResponse).position,
    company: JSON.parse(aiResponse).company,
    description: JSON.parse(aiResponse).description,
    startDate: JSON.parse(aiResponse).startDate,
    endDate: JSON.parse(aiResponse).endDate,
  } satisfies WorkExperience;
}

import { Prisma } from "@prisma/client";
import { ResumeValues } from "./validation";

export interface EditorFormProps {
  resumeData: ResumeValues;
  setResumeData: (data: ResumeValues) => void;
}

export const resumeDataInclude = {
  workExperiences: true,
  educations: true,
} satisfies Prisma.ResumeInclude;

export type ResumeServerData = Prisma.ResumeGetPayload<{
  include: typeof resumeDataInclude;
}>;


export interface JobInterface {
  title: string;
  company_name: string;
  location: string;
  via: string;
  description: string;
  detected_extensions: {
    posted_at?: string;
    schedule_type?: string;
    work_from_home?: boolean;
  };
  apply_options: Array<{
    title: string;
    link: string;
  }>;
  share_link: string;
  extensions: string[];
  job_id: string;
}

export interface SearchParams {
  keywords: string;
  location: string;
  page: number;
  roles: string[];
  skills: string[];
  locations: string[];
  pageNumber?: number;
}


export interface AIResponse {
  skillGapAnalysis: {
    strengths: string[];
    weaknesses: string[];
    criticalDeficiencies: string[];
    industryStandardProficiencies: Array<{
      skill: string;
      requiredProficiency: number;
    }>;
  };
  strategicLearningPath: {
    phases: Array<{
      phaseTitle: string;
      description: string;
      conceptsToMaster: string[];
      technologiesToLearn: string[];
    }>;
  };
  learningInterventions: Array<{
    courseTitle: string;
    platform: string;
    link: string;
    description: string;
  }>;
  tacticalTimeline: Array<{
    phase: string;
    duration: string;
    milestones: string[];
  }>;
  emergingTrends: string[];
  careerProgression: {
    currentRole: string;
    futureRoles: string[];
    transitionSteps: string[];
  };
}